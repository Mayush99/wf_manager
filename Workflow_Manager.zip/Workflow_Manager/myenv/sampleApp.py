'''
Controller Manager:

Sensor Manager :
                sensortypealias = {
                    "AQ": ["Air_Quality"],
                    "WE": ["Weather"],
                    "SR": ["Soil"],
                    "SL": ["Solar_Energy"],
                    "EM": ["Energy_Monitoring"]
                }
                    
'''
# modificaton has to be done in platform for now..
'''
TO ADD in  internal api....

@router.post("/push_notification", dependencies=[Depends(JWTBearer())])
async def push_notification(email: str, message: str, subject: str, app_name: str):
    if not email or not message or not app_name:
        raise HTTPException(status_code=400, detail="email, message, and app_name are required")

    key = ""
    body = f"{app_name}: {message}"
    msg = {"receiver_email": email, "subject": subject, "body": body}

    try:
        produce.push("topic_notification", key, json.dumps(msg))
        return {"status": 200, "data": "Notification sent successfully"}
    except (Exception) as e:
        return {"status": 500, "data": f"Failed to send notification: {str(e)}"}

'''
from http.client import HTTPException
import json
import random
from fastapi import FastAPI, Response
import requests
from datetime import timedelta
import datetime
# from remotecalls import *
from fastapi.responses import HTMLResponse
import statistics
app = FastAPI()
from Messenger import Produce

produce=Produce()
#Platform IP port..
IP = "127.0.0.1"
PORT = "8005"
MY_APP_NAME = "sampleApp"
USER_MAIL = "sharmamht19@gmail.com"

# Threshold values for normal/good condition
air_quality_threshold = 50  # Assumes AQI threshold of 50
solar_energy_threshold = 500  # Assumes solar radiation threshold of 500 W/m^2

# good range of sensor values...
solar_energy_range = (40, 80)
air_quality_range = (10, 50)
room_energy_range = (5, 15)

# Time interval for checking sensor values
time_interval = timedelta(seconds=5)

last_checked_time = None
curr_time = "2023-01-06T20:20:01Z"


#*******************************************| managers |****************************************


def check_sensor_values(air_quality_sensors, solar_energy_sensors):
    try:
        for sensor_value in air_quality_sensors:
            if not air_quality_range[0] <= sensor_value <= air_quality_range[1]:
                return False
        for sensor_value in solar_energy_sensors:
            if not solar_energy_range[0] <= sensor_value <= solar_energy_range[1]:
                return False
    except TypeError:
        return False
    return True

#send notification to user.
def send_notification(email, message, subject):
    if email is None or message is None or subject is None:
        raise ValueError("Email, message, and subject cannot be None")

    url = "http://127.0.0.1:8001/push_notification"
    data = {
        "email": email,
        "message": message,
        "subject": subject,
        "app_name": MY_APP_NAME
    }
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status() # Raises a HTTPError if the response contains an error status code
        print(f"Notification sent successfully to {email}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending notification to {email}: {e}")
    except ValueError as e:
        print(f"Error sending notification to {email}: {e}")

# Control Messages for controllers.....
def send_control_messages(fans=None, lights=None, ac=None):
    if fans is not None:
        # Send control message to fans controller
        print(f"Sending message to fans controller: Turn {'on' if fans else 'off'} the fans")

    if lights is not None:
        # Send control message to lights controller
        print(f"Sending message to lights controller: Turn {'on' if lights else 'off'} the lights")

    if ac is not None:
        # Send control message to AC controller
        print(f"Sending message to AC controller: Turn {'on' if ac else 'off'} the AC")

#get sensor data from platform.
def get_sensor_data(type = None):
    # Call the API endpoint to get the sensor data
    '''
        response = "requests.get(api_url)"
        sensor_data = response.json()

        To Do: need to call api's to get sensor data, then fromat data based in requirments.
    '''

    if(type == "aq_check"):
        # Simulate getting sensor data from 3 air quality sensors and 2 solar energy sensors.
        sensor_data = {
            "air_quality": [random.randint(5, 55), random.randint(5, 55), random.randint(5, 55)],
            "solar_energy": [random.randint(35,85), random.randint(35,85)]
        }
        return sensor_data
    
    elif(type == "energy_saving"):
        # Simulate getting sensor data from 3 air quality sensors and 2 solar energy sensors
        sensor_data = {
            "air_quality": [random.randint(5, 60), random.randint(5, 55)],
            "solar_energy": [random.randint(37,85), random.randint(35,85), random.randint(38,85)],
            "room_energy" : [random.randint(1, 20)]
        }
        return sensor_data
    
    else:
        return {}


# def get_sensor_data1(parms):
#     return fetchdatafromtype(parms)



#*******************************************| API's |****************************************

@app.get("/")
async def index(response: Response):
    html = """
        <html>
            <head>
                <style>
                    body {
                        background-color: #e6e6e6;
                        font-family: Arial, sans-serif;
                    }
                    
                    .container {
                        max-width: 800px;
                        margin: auto;
                        padding: 20px;
                        background-color: #fff;
                        box-shadow: 0 0 10px rgba(0,0,0,0.1);
                        border-radius: 5px;
                    }
                    
                    h1, h2, h3 {
                        color: #333;
                        text-align: center;
                        margin-top: 0;
                    }
                    
                    button {
                        background-color: #4CAF50;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 5px;
                        cursor: pointer;
                    }
                    
                    button:hover {
                        background-color: #3e8e41;
                    }
                    
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Welcome to Sample App</h1>
                    <p><b>Room monitoring system:</b> This is a web application used to understand the air, energy and solar
conditions of the particular location and send control to respective controllers. Also send
notification/email to the subscribed user.</p>
                    
                </div>
            </body>
        </html>
        """

    return HTMLResponse(content=html, status_code=200)


# Feature - 1
@app.get("/aq_check")
async def aq_check():
    SUBOPTIMAL_MSG = "Room conditions are not optimal, turn on the fans and A/C."
    OPTIMAL_MSG = "Room conditions are optimal, turn off the fans and A/C."
    try:
        # Fetch real-time sensor data
        sensor_data = get_sensor_data(type="aq_check")

        # Extract air quality and solar energy sensor values
        air_quality_sensors = sensor_data.get('air_quality', [])
        solar_energy_sensors = sensor_data.get('solar_energy', [])

        # Check sensor values
        if check_sensor_values(air_quality_sensors, solar_energy_sensors):
            # Send notification to user
            send_notification(USER_MAIL, message=OPTIMAL_MSG, subject="Optimal room conditions")

            # Send control messages to the controllers
            send_control_messages(fans=False, ac=False)

            # Return response with the message to turn off the fans and A/C
            return {"message": OPTIMAL_MSG}
        else:
            # Send notification to user
            send_notification(USER_MAIL, message=SUBOPTIMAL_MSG, subject="Suboptimal room conditions")

            # Send control messages to the controllers
            send_control_messages(fans=True, ac=True)

            # Return response with the message to turn on the fans and A/C
            return {"message": SUBOPTIMAL_MSG}

    except Exception as e:
        # Handle errors
        return {"message": "An error occurred while processing the request."}

# feature - 2
@app.get('/energy_saving')
def energy_saving():
    global last_checked_time
    
    try:
        # Get current time
        current_time = datetime.datetime.now()

        # Fetch real-time sensor data for energy saving
        sensor_data = get_sensor_data(type="energy_saving")

        # Check if all required sensor data is available
        if "solar_energy" not in sensor_data or "air_quality" not in sensor_data or "room_energy" not in sensor_data:
            raise ValueError("Missing sensor data for energy saving")

        # Extract sensor values within range
        solar_energy_sensors = [value for value in sensor_data['solar_energy'] if value >= solar_energy_range[0] and value <= solar_energy_range[1]]
        air_quality_sensors = [value for value in sensor_data['air_quality'] if value >= air_quality_range[0] and value <= air_quality_range[1]]
        room_energy_monitoring = [value for value in sensor_data['room_energy'] if value >= room_energy_range[0] and value <= room_energy_range[1]]

        # Check if all sensor values are within range
        if len(solar_energy_sensors) == len(sensor_data['solar_energy']) and len(air_quality_sensors) == len(sensor_data['air_quality']) and len(room_energy_monitoring) == len(sensor_data['room_energy']):
            send_control_messages(fans=True, lights=True, ac=True)
            return {'message': 'All sensor values are in range. No action required.'}

        # Check if sensor values are out of range for a time interval
        if last_checked_time is None or current_time - last_checked_time >= time_interval:
            last_checked_time = current_time

            # Check solar energy
            if len(solar_energy_sensors) < len(sensor_data['solar_energy']):
                energy_preserved = len(room_energy_monitoring) == len(sensor_data['room_energy']) and all(value >= 10 for value in room_energy_monitoring)
                if energy_preserved:
                    send_control_messages(lights=False)
                    return {'message': 'Solar energy values are out of range, but energy is preserved. Only lights are turned off.'}
                else:
                    send_control_messages(lights=False, ac=False)
                    return {'message': 'Solar energy values are out of range, and energy is not preserved. Lights and A/C are turned off.'}

            # Check air quality
            elif len(air_quality_sensors) < len(sensor_data['air_quality']):
                energy_preserved = len(room_energy_monitoring) == len(sensor_data['room_energy']) and all(value >= 10 for value in room_energy_monitoring)
                if energy_preserved:
                    send_control_messages(fans=False)
                    return {'message': 'Air quality values are out of range, but energy is preserved. Only fans are turned off.'}
                else:
                    send_control_messages(fans=False, ac=False)
                    return {'message': 'Air quality values are out of range, and energy is not preserved. Fans and A/C are turned off.'}

        # If sensor values are out of range but not for a time interval, no action is required
        else:
            return {'message': f'Sensor values are out of range but have not been for {time_interval} yet. No action required.'}

    except Exception as e:
        # Handle any unexpected errors
        return {'message': f'Error: {e}'} 


@app.post("/push_notification")
async def push_notification(email: str, message: str, subject: str, app_name: str):
    if not email or not message or not app_name:
        raise HTTPException(
            status_code=400, detail="email, message, and app_name are required")

    key = ""
    body = f"{app_name}: {message}"
    msg = {"receiver_email": email, "subject": subject, "body": body}

    try:
        produce.push("topic_notification", key, json.dumps(msg))
        return {"status": 200, "data": "Notification sent successfully"}
    except (Exception) as e:
        return {"status": 500, "data": f"Failed to send notification: {str(e)}"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
    # parms = {
    #     "sensortype": "Energy_Monitoring",
    #     "starttime": curr_time,
    #     "numofsensors": 1,
    #     "data_flag": True
    # }
    # data = get_sensor_data1(parms)
    # with open("data.json", "w") as f:
    #     json.dump(data, f)

