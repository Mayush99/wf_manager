from services import service_req
def wf_name_18(par_1 , par_2 , par_3):
	D = dict()
	print('inside workflow')
	foo_op = service_req("foo", [par_1,par_2])
	D["foo"] = foo_op

	if(par_3>=par_1):
		foobar_op = service_req("foobar", [])
		D["foobar"] = foobar_op
	else:
		foobar_op = service_req("foobar", [])
		D["foobar"] = foobar_op

	foobar_op = service_req("foobar", [])
	D["foobar"] = foobar_op


	if(D["foo"]["key1"]>=par_1):
		foobar_op = service_req("foobar", [])
		D["foobar"] = foobar_op
	else:
		bar_op = service_req("bar", [par_1,D["foo"]["key2"]])
		D["bar"] = bar_op
	print(D)
if __name__ == '__main__':
	wf_name_18(12,'ayush',100)