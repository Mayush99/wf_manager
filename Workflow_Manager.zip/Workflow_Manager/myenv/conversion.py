import json

def convert(data):
    contract = {
        "custom_workflow": {
            "app_name": "",
            "schedule_info": "",
            "workflow_name": "",
            "params_count": 0,
            "workflow_fn_parameters": {
                "param_name": [],
                "param_vals": [],
                "param_dtype": []
            },
            "service_list": [
            ]
        }
    }

    # with open(f_name) as node:
    #     data = json.load(node)

    app_name = data[0]["app_name"]
    schedule_info = data[0]["schedule_info"]
    wf_name = data[0]["label"]

    for i in range(len(data)):
        if(data[i]["type"]=="inject"):
            wire = data[i]["wires"][0][0]
            # print(wire)
            break

    for i in range(len(data)):
        if (data[i]["type"] == "http request" and wire == data[i]["id"]):
            url = data[i]["url"]
            service = url.split("/")[-1]
            contract["custom_workflow"]["app_name"] = app_name
            contract["custom_workflow"]["schedule_info"] = schedule_info
            contract["custom_workflow"]["workflow_name"] = wf_name
            contract["custom_workflow"]["service_list"].append({"type":"service", "service_name": service, "param_count":0, "params_list":[]})
            # print(contract)
            wire = data[i]["wires"][0][0]
            # print(wire)

    again = True
    for j in range(len(data)):
        if(again):
            for i in range(len(data)):
                if(data[i]["type"]=="http request" and data[i]["id"]==wire):
                    wire = data[i]["wires"][0][0]
                    service = data[i]["url"].split("/")[-1]
                    contract["custom_workflow"]["service_list"].append(
                        {"type": "service", "service_name": service, "param_count": 0, "params_list": []})
                    again = True
                else:
                    again = False
        else:
            break

    # print(contract)    
    return (contract)