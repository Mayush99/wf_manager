from fastapi import FastAPI
import os
import shutil
import json
import uvicorn
from fastapi import FastAPI, Request, Form, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from fastapi import BackgroundTasks
from conversion import convert

app = FastAPI()

@app.post("/upload_file")
async def upload_file(file: UploadFile, background_tasks: BackgroundTasks):
    if file.content_type != "application/json":
        raise HTTPException(400, detail="Invalid file type")

    data=json.loads(file.file.read())
   
    is_created, app_name, wf_name = define_workflow_complex(data)
    background_tasks.add_task(bg_task)
    return {"success":1, "is_created":is_created, "app_name" : app_name, "wf_name":wf_name}


@app.post("/upload_file_nodered_flow")
async def upload_file_nodered_flow(file: UploadFile, background_tasks: BackgroundTasks):
    if file.content_type != "application/json":
        raise HTTPException(400, detail="Invalid file type")

    nodered_data=json.loads(file.file.read())
    
    # convert from node-red format to our contract.json format
    data = convert(nodered_data)

    is_created, app_name, wf_name = define_workflow_complex(data)
    background_tasks.add_task(bg_task)
    return {"success": 1, "is_created": is_created, "app_name": app_name, "wf_name": wf_name}

def bg_task():
    os.system("python3 cron.py")

# @app.get("/foo")
# def foo_api(inp1: int, inp2: str):
#    data = {"key1": inp1, "key2" : inp2}
#    return data

# @app.get("/bar")
# def bar_api(inp11: int, inp21: str):
#    data = {"key11": inp11, "key21" : inp21}
#    return data

# @app.get("/foobar")
# def foo_bar_api():
#    data = {"msg":"Message from foobar"}
#    return data

@app.get("/call_wf/{app_name}/{wf_name}")
def call_wf_api(app_name, wf_name):
   folder = "./workflow/"+app_name
   
   f=open("./config.json")
   config=json.loads(f.read())
   python_env = config["python_env"]
   f.close()
   
   cmd = python_env + " " + folder+"/"+wf_name+".py"
   j = os.system(cmd)
   
   if(j == 0):
    is_called = True
   else:
    is_called = False
   
   return {"success":is_called}

# def schedule_wf(app_name, wf_name, schedule_info):
#     cron = CronTab(user=True)
#     l = schedule_info.split()
    
#     f=open("./config.json")
#     config=json.loads(f.read())
#     python_env = config["python_env"]
#     small_workflow_folder_path = config["small_workflow_folder_path"]
#     f.close()

#     abs_path = small_workflow_folder_path+"/"+app_name

#     job = cron.new(command=python_env +' '+abs_path+'/'+wf_name+'.py')

#     job.minute.every(1)
#     cron.write()

def get_service(service):
    service_name = service["service_name"]
    params_count = service["param_count"]
    service_op = service_name + "_op"

    if(len(service["params_list"]) != params_count):
        print("Parameter count do not match..!!")
        return (False, "")

    args = ""

    for params in service["params_list"]:
        if(params["prev_service_output"] == "False"):
            args += (params["param_name"] + ',')
        else:
            val = params["param_name"].split('.')
            args += f'D["{val[0]}"]["{val[1]}"],'

    args = args[:-1]

    op_add_line = f'D["{service_name}"] = {service_op}'
    service_req_line = f'{service_op} = service_req("{service_name}", [{args}])'

    return service_req_line, op_add_line, service_op

def get_conditional(service):
    cond = service["cond"]
    cond_line = "if("

    if(cond == "gte"):
        opr = ">="
    elif(cond == "gt"):
        opr = ">"
    elif(cond == "lte"):
        opr = "<="
    elif(cond == "lt"):
        opr = "<"
    elif(cond == "eq"):
        opr = "=="

    # for left side value
    if(service["comp_val_lhs_from_prev_serv"] == "True"):
        comp_val_lhs = service["comp_val_lhs"].split('.')
        cond_line += f'D["{comp_val_lhs[0]}"]["{comp_val_lhs[1]}"]'
    else:
        cond_line += service["comp_val_lhs"]
    
    cond_line += opr

    # for right side value
    if(service["comp_val_rhs_from_prev_serv"] == "True"):
        comp_val_rhs = service["comp_val_rhs"].split('.')
        cond_line += f'D["{comp_val_rhs[0]}"]["{comp_val_rhs[1]}"],'
    else:
        cond_line += service["comp_val_rhs"]
    
    cond_line += "):\n"

    service_req_line, op_add_line, service_op = get_service(service["if_true"])
    cond_line += f'\t\t{service_req_line}\n\t\t{op_add_line}\n'

    service_req_line, op_add_line, service_op = get_service(service["if_false"])
    cond_line += f'\telse:\n\t\t{service_req_line}\n\t\t{op_add_line}'

    return cond_line

def define_workflow_complex(contract_object):
    # file_to_save_folder = "/data"
    # test_logger_file_name = "logger_new.txt"  

    work_details = contract_object["custom_workflow"]
    app_name = work_details["app_name"] 

    #append new app-apis created by developer
    # with open("exposed_urls.json", "r") as jsonFile:
    #     eu = json.load(jsonFile)
    # # if workflow_name in data.keys():
    # services = work_details["service_list"]
    # for i in range(len(services)):
    #     if(services[i]["type"]=="service"):
    #         eu[services[i]["service_name"]] = dict({"url": services[i]["url"],"version":1.0, "input":[], "output":[]})
    # with open("exposed_urls.json", "w") as fp:
    #     json.dump(eu, fp)

    # if os.path.exists('workflow/'+app_name):
    #     shutil.copy("services.py", "./workflow/"+app_name+"/services.py")
    #     shutil.copy("exposed_urls.json", "./workflow/"+app_name+"/exposed_urls.json")

    if not os.path.exists('workflow/'+app_name):
       os.makedirs('workflow/'+app_name) 
       shutil.copy("services.py", "./workflow/"+app_name+"/services.py")
       shutil.copy("exposed_urls.json", "./workflow/"+app_name+"/exposed_urls.json")
   
    workflow_name = work_details["workflow_name"]
    workflow_params_data = work_details["workflow_fn_parameters"]
    workflow_params_vals = workflow_params_data["param_vals"]
    workflow_params_dtype = workflow_params_data["param_dtype"]

    workflow_params = " , ".join(x for x in workflow_params_data["param_name"])

    service_req_list = []
    op_add_list = []
    service_op_list = []
    condl_list = []

    for idx, service in enumerate(work_details["service_list"]):
        if(service["type"] == "service"):
            service_req_line, op_add_line, service_op = get_service(service)
            
            service_req_list.append(service_req_line)
            op_add_list.append(op_add_line)
            service_op_list.append(service_op)
        
        elif(service["cond"] != "-"):
            cond_line = get_conditional(service)
            condl_list.append((idx-1, cond_line))

    # write code lines to file
    folder = "./workflow/"+app_name
    f = open(folder+"/"+workflow_name+".py","w")

    f.write("from services import service_req\n")
    f.write(f'def {workflow_name}({workflow_params}):\n')
    f.write(f'\tD = dict()\n')
    f.write("\tprint('inside workflow')\n")

    ptr = 0

    for i, service_call in enumerate(service_req_list):
        f.write(f'\t{service_call}\n')
        f.write(f'\t{op_add_list[i]}\n')
        if(ptr < len(condl_list) and condl_list[ptr][0] == i):
            f.write(f'\n')
            f.write(f'\t{condl_list[ptr][1]}\n')
            ptr += 1
        f.write(f'\n')
        
    while(ptr < len(condl_list)):
        f.write(f'\n')
        f.write(f'\t{condl_list[ptr][1]}\n')
        ptr += 1
    f.write("\tprint(D)")
    f.write("\n")

    # Write to file for testing
    # f.write(f'\tf = open("{file_to_save_folder}/{test_logger_file_name}","a")\n')
    # f.write(f'\tf.write("Workflow Called..")\n')
    # f.write("\tf.close()\n")
    if(work_details["schedule_info"]!="0 0 0 0 0"):
        with open("wf_sched.json", "r") as jsonFile:
            data = json.load(jsonFile)
        # if workflow_name in data.keys():
            data[workflow_name] = list()
            data[workflow_name].append(work_details["schedule_info"])
            data[workflow_name].append(app_name)
        with open("wf_sched.json", "w") as fp:
            json.dump(data, fp)

    f.write("if __name__ == '__main__':\n")
    
    arguments = ""
    for idx, val in enumerate(workflow_params_vals):
        if(workflow_params_dtype[idx] == "str"):    
            arguments += f"'{val}',"
        else:
            arguments += f"{val},"
    
    arguments = arguments[:-1]
    
    f.write(f"\t{workflow_name}({arguments})")

    f.close()

    return (True, app_name, workflow_name)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0",port=8002)