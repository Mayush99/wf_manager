from rocketry import Rocketry
from rocketry.conds import cron
import os
app = Rocketry()
@app.task(cron("* * * * *"))
def cron______():
    os.system("python3 /home/mayush/Documents/IAS/FinalIAS/Workflow_Manager/myenv/workflow/app_8/wf_name_18.py")

app.run()