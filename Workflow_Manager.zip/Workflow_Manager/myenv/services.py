import json 
import requests

def service_req(service_name, args):
    if(service_name == "do_nothing"):
        return {"op" : "NOP"}

    print()
    # reading ip and port information from server_info
    
    f=open("server_info.json")
    server_info = json.load(f)
    f.close()

    print("Calling " + service_name)

    f = open("exposed_urls.json")
    eud = json.load(f)
    f.close()

    url = "http://"+server_info["server_ip"]+":"+server_info["port"]+"/"+service_name
    input = eud[service_name]['input']

    params = {}
    
    for i, arg in enumerate(args):
        params[input[i]['name']] = arg

    # print(params)

    response = requests.get(url, params=params)

    if response.status_code == 200:
        print(service_name + " executed successfully..!!")
        print("Finishing " + service_name)
        return response.json()
    
    else:
        print(service_name + " failed..!!")
        return {"error" : True}
    