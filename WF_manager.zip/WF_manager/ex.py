import os

os.system("python3 ./workflow/app_8/real_workflow.py")
