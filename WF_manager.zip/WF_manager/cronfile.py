from rocketry import Rocketry
from rocketry.conds import cron
import os
app = Rocketry()
print('cronfile runiing')
@app.task(cron("*/2 * * * *"))
def cron_2_____():
    os.system("python3 ./workflow/app_8/real_workflow.py")

app.run()