from services import service_req
def real_workflow(sensortype , starttime , numofsensors , data_flag , threshold , email , message , subject , app_name):
	D = dict()
	print('inside workflow')
	fetchSensorData_op = service_req("fetchSensorData", [sensortype,starttime,numofsensors,data_flag])
	D["fetchSensorData"] = fetchSensorData_op

	if(threshold>=D["fetchSensorData"]["data"]["PM2.5"]):
		push_notification_op = service_req("push_notification", [email,message,subject,app_name])
		D["push_notification"] = push_notification_op
	else:
		do_nothing_op = service_req("do_nothing", [])
		D["do_nothing"] = do_nothing_op

	print(D)
if __name__ == '__main__':
	real_workflow('AQ','2023-01-06T20:20:01Z',1,True,34.5,'lakshakarayush@gmail.com','Msg from WF Manager','Subject-Msg from WF Manager','app_8')