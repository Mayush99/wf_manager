import json
import pathlib
import os

writelines = ""
cronfile = open("cronfile.py", "w")
writelines += "from rocketry import Rocketry\nfrom rocketry.conds import cron\nimport os\napp = Rocketry()\nprint('cronfile runiing')\n"
cronfile.writelines(writelines)
cronfile.close()

with open("wf_sched.json") as wf_sched:
    data = json.load(wf_sched)

for key in data.keys():
    cron = data[key][0]
    app_name = data[key][1]
    print(cron, app_name, "***********")
    cronfile = open("cronfile.py", "r")
    filled = False
    count = 0
    writelines = ""
    for line in cronfile:
        writelines += line
        # @app.task(cron("0 10 * * *"))
        count -= 1
        if line[:4] == "@app":
            if line[16:16+len(cron)] == cron:
                count = 2
                filled = True
        if (filled and count == 0):
            writelines += '    os.system("python3 ./workflow/'+app_name+'/'+key+'.py")\n'
            
    if filled == False:
        writelines += '@app.task(cron("'+data[key][0]+'"))\n'
        writelines += "def cron_"+'_'.join(data[key][0].replace("*", "").replace(
            "/", "").replace("-", "").replace(",", "").split(" "))+"_():\n"
        writelines += '    os.system("python3 ./workflow/' + \
            app_name+'/'+key+'.py")\n'
    cronfile.close()
    cronfile = open("cronfile.py", "w")
    cronfile.writelines(writelines)
    cronfile.close()

lines = open("cronfile.py", 'r').readlines()

new_last_line = "\napp.run()"
lines += new_last_line
open("cronfile.py", 'w').writelines(lines)
print("starting cronfile")
os.system("python3 cronfile.py")
