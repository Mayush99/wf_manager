from fastapi import FastAPI
import os
import shutil
import json
import uvicorn
from fastapi import FastAPI, Request, Form, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse

app = FastAPI()

@app.get("/foo")
def foo_api(inp1: int, inp2: str):
   data = {"key1": inp1, "key2": inp2}
   return data


@app.get("/bar")
def bar_api(inp11: int, inp21: str):
   data = {"key11": inp11, "key21": inp21}
   return data


@app.get("/foobar")
def foo_bar_api():
   data = {"msg": "Message from foobar"}
   return data

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0",port=8005)